IMPRÉSSION 3D — SITE DE DÉPART

Le site est une première version fonctionnelle côté présentation : accueil, boutique de 20 produits, recherche, catégories, panier visuel, nouveautés, promotions, fonctionnement, à-propos et contact.

Les images sont des placeholders. Pour les modèles/images Tinkercad, utiliser uniquement ceux dont la licence autorise explicitement l'utilisation commerciale.

Le paiement réel, le calcul des frais de livraison et le traitement des commandes devront être connectés à un service de paiement/backend lors de la mise en ligne.
